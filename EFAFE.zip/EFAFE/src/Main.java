import java.util.Arrays;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        double ventas[]=new double[6];
        double mayor=ventas[0];
        Scanner sc=new Scanner(System.in);
        System.out.println("Ingrese las 6 ventas del mes:");
        for(int i=0;i<ventas.length;i++)
        {
            System.out.println("Venta "+(i+1));
            ventas[i]=sc.nextDouble();
            if (ventas[i]>ventas[0])
            {
                mayor=ventas[i];
                System.out.println("La mayor venta es :"+mayor);
            }
        }

        int k=0;
        int total=0;
        while(k<6)
        {
            if (ventas[k] >= 2000)
            {
                System.out.println(ventas[k]);
                total++;
            }
            k++;
        }
        System.out.println("El total de ventas mayores a 2000 es :"+total);
        System.out.println(Arrays.toString(ventas));
        System.out.println("La mayor venta es :"+mayor);
     }
}

